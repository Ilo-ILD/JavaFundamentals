
public class AssignVariables {
    public static void main(String[] args) {
        byte byt = 127;
        short shor = 32767;
        int iniger = 2000000000;
        long lon = 919827112351L;
        float floa = 0.5f;
        double doub = 0.1234567891011;
        char charr = 'c';
        String str = "Palo Alto, CA";
        boolean bool = false;
    }
}
