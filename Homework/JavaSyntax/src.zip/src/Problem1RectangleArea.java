import java.util.Scanner;

public class Problem1RectangleArea {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int numA = in.nextInt();
        int numB = in.nextInt();

        System.out.println(numA*numB);
    }
}
